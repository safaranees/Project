package org.hcl.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name = "item")
public class PetAnimal  {

	@Id
	@Column(name = "Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String petAnimalId;
	
	@Column(name="category")
	private String petAnimalCategory;
	
	@Column(name = "description")
	private String petAnimalDescription;
	
	@NotEmpty(message = "PetAnimal Name is mandatory")
	@Column(name = "name")
	private String petAnimalName;
	
	@NotNull(message="Please provide some price")
	@Min(value = 100, message = "Minimum value should be greater than 100")
	@Column(name = "price")
	private double petAnimalPrice;
	
	@Column(name = "unit")
	private String unitStock;

	public String getPetAnimalId() {
		return petAnimalId;
	}

	public void setPetAnimalId(String petAnimalId) {
		this.petAnimalId = petAnimalId;
	}

	public String getPetAnimalCategory() {
		return petAnimalCategory;
	}

	public void setPetAnimalCategory(String petAnimalCategory) {
		this.petAnimalCategory = petAnimalCategory;
	}

	public String getPetAnimalDescription() {
		return petAnimalDescription;
	}

	public void setPetAnimalDescription(String petAnimalDescription) {
		this.petAnimalDescription = petAnimalDescription;
	}

	public String getPetAnimalName() {
		return petAnimalName;
	}

	public void setPetAnimalName(String petAnimalName) {
		this.petAnimalName = petAnimalName;
	}

	public double getPetAnimalPrice() {
		return petAnimalPrice;
	}

	public void setPetAnimalPrice(double petAnimalPrice) {
		this.petAnimalPrice = petAnimalPrice;
	}

	public String getUnitStock() {
		return unitStock;
	}

	public void setUnitStock(String unitStock) {
		this.unitStock = unitStock;
	}

	

	
}
