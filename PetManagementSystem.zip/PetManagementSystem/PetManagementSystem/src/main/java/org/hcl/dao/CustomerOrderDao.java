package org.hcl.dao;

import org.hcl.entities.CustomerOrder;

public interface CustomerOrderDao {

	void addCustomerOrder(CustomerOrder customerOrder);
}
