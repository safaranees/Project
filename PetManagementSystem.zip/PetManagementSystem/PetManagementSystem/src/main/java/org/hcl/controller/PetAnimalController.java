
package org.hcl.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ModelAndView;

import org.hcl.entities.PetAnimal;
import org.hcl.service.PetAnimalService;

@Controller
public class PetAnimalController {

	@Autowired
	private PetAnimalService petAnimalService;

	public PetAnimalService getPetAnimalService() {
		return petAnimalService;
	}

	public void setPetAnimalService(PetAnimalService petAnimalService) {
		this.petAnimalService = petAnimalService;
	}

	
	@Bean
	public MultipartResolver multipartResolver() {
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
		multipartResolver.setMaxUploadSize(10240000);
		return multipartResolver;
	}

	
	  @RequestMapping("/getAllPetAnimal") public ModelAndView getAllPetAnimal() {
	  List<PetAnimal> petAnimal = petAnimalService.getAllPetAnimal(); return new
	  ModelAndView("petAnimalList", "petAnimal", petAnimal); }
	 
	@RequestMapping("getPetAnimalById/{petAnimalId}")
	public ModelAndView getPetAnimalById(@PathVariable(value = "petAnimalId") String petAnimalId) {
		PetAnimal petAnimal = petAnimalService.getPetAnimalById(petAnimalId);
		return new ModelAndView("petAnimalPage", "petAnimalObj", petAnimal);
	}

	@RequestMapping("/admin/delete/{petAnimalId}")
	public String deletePetAnimal(@PathVariable(value = "petAnimalId") String petAnimalId) {
		petAnimalService.deletePetAnimal(petAnimalId);
		return "redirect:/getAllPetAnimal";
	}

	@RequestMapping(value = "/admin/petAnimal/addPetAnimal", method = RequestMethod.GET)
	public String getPetAnimalForm(Model model) {
		PetAnimal petAnimal = new PetAnimal();
		petAnimal.setPetAnimalCategory("Android");
		model.addAttribute("petAnimalFormObj", petAnimal);
		return "addPetAnimal";

	}

	@RequestMapping(value = "/admin/petAnimal/addPetAnimal", method = RequestMethod.POST)
	public String addPetAnimal(@Valid @ModelAttribute(value = "petAnimalFormObj") PetAnimal petAnimal, BindingResult result) {
		if (result.hasErrors())
			return "addPetAnimal";
		petAnimalService.addPetAnimal(petAnimal);
		return "redirect:/getAllPetAnimal";
	}

	@RequestMapping(value = "/admin/petAnimal/editPetAnimal/{petAnimalId}")
	public ModelAndView getEditForm(@PathVariable(value = "petAnimalId") String petAnimalId) {
		PetAnimal petAnimal = petAnimalService.getPetAnimalById(petAnimalId);
		return new ModelAndView("editPetAnimal", "editPetAnimalObj", petAnimal);
	}

	@RequestMapping(value = "/admin/petAnimal/editPetAnimal", method = RequestMethod.POST)
	public String editPetAnimal(@ModelAttribute(value = "editPetAnimalObj") PetAnimal petAnimal) {
		petAnimalService.editPetAnimal(petAnimal);
		return "redirect:/getAllPetAnimal";
	}

	@RequestMapping("/getPetAnimalList")
	public @ResponseBody List<PetAnimal> getPetAnimalListInJson() {
		return petAnimalService.getAllPetAnimal();
	}

	@RequestMapping("/petAnimalListAngular")
	public String getPetAnimal() {
		return "petAnimalListAngular";
	}

}
