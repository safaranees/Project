package org.hcl.service;

import java.util.List;

import org.hcl.entities.PetAnimal;

public interface PetAnimalService {

	public List<PetAnimal> getAllPetAnimal();

	PetAnimal getPetAnimalById(String petAnimalId);

	void deletePetAnimal(String petAnimalId);
	
	void addPetAnimal(PetAnimal petAnimal);
	
	void editPetAnimal(PetAnimal petAnimal);

}
