package org.hcl.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "cartitem")
public class CartItem {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String cartItemId;

	private int quality;

	private double price;

	@ManyToOne
	@JoinColumn(name = "petAnimaltId")
	private PetAnimal petAnimal;

	@ManyToOne
	@JoinColumn(name = "cartId")
	//private Cart cart;
	private Cart cart;

	public String getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(String cartItemId) {
		this.cartItemId = cartItemId;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public PetAnimal getPetAnimal() {
		return petAnimal;
	}

	public void setPetAnimal(PetAnimal petAnimal) {
		this.petAnimal = petAnimal;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	

}
