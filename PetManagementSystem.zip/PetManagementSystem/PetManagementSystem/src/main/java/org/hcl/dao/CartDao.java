package org.hcl.dao;

import java.io.IOException;

import org.hcl.entities.Cart;
import org.hcl.entities.CartItem;

public interface CartDao {

	Cart getCartByCartId(String CartId);
	
	Cart validate(String cartId) throws IOException;
	
	void update(Cart cart);
}
