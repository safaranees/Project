package org.hcl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.hcl.dao.PetAnimalDao;
import org.hcl.entities.PetAnimal;

@Service(value="petAnimalService")
public class PetAnimalServiceImpl implements PetAnimalService {

	@Autowired
	private PetAnimalDao petAnimalDao;

	public PetAnimalDao getPetAnimalDao() {
		return petAnimalDao;
	}

	public void setPetAnimalDao(PetAnimalDao petAnimalDao) {
		this.petAnimalDao = petAnimalDao;
	}

	@Transactional
	public List<PetAnimal> getAllPetAnimal() {
		return petAnimalDao.getAllPetAnimal();
	}

	
	public PetAnimal getPetAnimalById(String petAnimalId) {
		return petAnimalDao.getPetAnimalById(petAnimalId);
	}

	
	public void deletePetAnimal(String petAnimalId) {
		petAnimalDao.deletePetAnimal(petAnimalId);
	}
	
	public void addPetAnimal(PetAnimal petAnimal){
		petAnimalDao.addPetAnimal(petAnimal);
	}
	
	public void editPetAnimal(PetAnimal petAnimal){
		petAnimalDao.editPetAnimal(petAnimal);
	}

}
