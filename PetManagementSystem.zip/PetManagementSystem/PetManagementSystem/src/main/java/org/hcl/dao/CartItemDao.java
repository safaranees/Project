package org.hcl.dao;

import org.hcl.entities.Cart;
import org.hcl.entities.CartItem;

public interface CartItemDao {

	void addCartItem(CartItem cartItem);
	void removeCartItem(String CartItemId);
	void removeAllCartItems(Cart cart);

}
