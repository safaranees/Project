package org.hcl.service;

import org.hcl.entities.*;

public interface CartService {

	Cart getCartByCartId(String CartId);
}
