package org.hcl.dao;

import java.util.List;

import org.hcl.entities.PetAnimal;

public interface PetAnimalDao {

	
	PetAnimal getPetAnimalById(String petAnimalId);

	void deletePetAnimal(String petAnimalId);

	void addPetAnimal(PetAnimal petAnimal);
	
	void editPetAnimal(PetAnimal petAnimal);

	List<PetAnimal> getAllPetAnimal();
	
}
