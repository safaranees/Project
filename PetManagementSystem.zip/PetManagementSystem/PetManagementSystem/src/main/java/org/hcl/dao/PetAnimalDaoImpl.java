package org.hcl.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.hcl.entities.PetAnimal;

@Repository(value = "petAnimalDao")
public class PetAnimalDaoImpl implements PetAnimalDao {

	@Autowired
	private SessionFactory sessionFactory;
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public PetAnimal getPetAnimalById(String petAnimalId) {
		Session session = sessionFactory.openSession();
		PetAnimal petAnimal = (PetAnimal) session.get(PetAnimal.class, petAnimalId);
		session.close();
		return petAnimal;
	}

	public void deletePetAnimal(String petAnimalId) {
		Session session = sessionFactory.openSession();
		PetAnimal petAnimal = (PetAnimal) session.get(PetAnimal.class, petAnimalId);
		session.delete(petAnimal);
		session.flush();
		session.close();
	}

	public void addPetAnimal(PetAnimal petAnimal) {
		Session session = sessionFactory.openSession();
		session.save(petAnimal);
		session.close();
	}

	public void editPetAnimal(PetAnimal petAnimal) {
		Session session = sessionFactory.openSession();
		session.update(petAnimal);
		session.flush();
		session.close();
	}

	@Override
	public List<PetAnimal> getAllPetAnimal() {
		Session session = sessionFactory.openSession();
		List<PetAnimal> petAnimal = session.createCriteria(PetAnimal.class).list();
		System.out.println("----- List of PetAnimal----");
		System.out.println(petAnimal);
		session.flush();
		session.close();
		return petAnimal;
	}

}
